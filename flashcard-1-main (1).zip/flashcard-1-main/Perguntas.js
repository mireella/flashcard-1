# flashcard-1
# flexcarflashcard
criaCartao(
    'Biologia Marinha',
    'O que é o plâncton?',
    'O plâncton é um conjunto de organismos microscópicos que flutuam nas águas oceânicas e servem de base para a cadeia alimentar marinha'
)

criaCartao(
    'Biologia Marinha',
    'O que é a Grande Barreira de Corais?',
    'A Grande Barreira de Corais é o maior sistema de recifes de coral do mundo, localizado na Austrália'
)

criaCartao(
    'Biologia Marinha',
    'O que são algas marinhas?',
    'Algas marinhas são organismos fotossintetizantes que vivem em ambientes aquáticos e desempenham um papel crucial na produção de oxigênio'
)

criaCartao(
    'Biologia Marinha',
    'Qual é o maior mamífero marinho?',
    'O maior mamífero marinho é a baleia-azul, que pode atingir mais de 30 metros de comprimento'
)

criaCartao(
    'Biologia Marinha',
    'O que é bioluminescência marinha?',
    'A bioluminescência é a produção de luz por organismos marinhos, como algumas espécies de medusas e peixes, geralmente para defesa ou atração de presas'
)
